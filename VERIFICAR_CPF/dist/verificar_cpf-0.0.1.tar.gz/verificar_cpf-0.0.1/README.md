# verificar_cpf

Description. 
The package verificar_cpf is used to:
    Inserir:
	    - Solicita que usuário digite o CPF.
    Verificar:
        - Calcula os dígitos verificadores.
        - Compara com os números do CPF informado e retorna se é válido.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install verificar_cpf

```bash
pip install verificar_cpf
```

## Author
Leonardo Diniz

## License
[MIT](https://choosealicense.com/licenses/mit/)